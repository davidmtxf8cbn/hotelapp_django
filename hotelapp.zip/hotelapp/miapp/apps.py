from django.apps import AppConfig


class miappConfig(AppConfig):
    name = 'miapp'
