from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.detail import DetailView
from django.urls import reverse_lazy
from .models import *
from django.http import HttpResponseRedirect

# Create your views here.

def index(request):
    return render(request, "miapp/index.html")

class habitacionList(ListView):
    model = habitacion
    template_name = "miapp/Listarhabitacion.html"

class habitacionDetalle(DetailView):
    model = habitacion
    template_name = 'miapp/detallehabitacion.html'

class habitacionCreate(CreateView):
    model = habitacion
    fields = ['num_habitacion','estado','precio','tipo_de_habitacion']
    template_name = 'miapp/nuevohabitacion.html'
    success_url = reverse_lazy('Listarhabitacion')

class habitacionUpdate(UpdateView):
    model = habitacion
    fields = ['num_habitacion','estado','precio','tipo_de_habitacion']
    template_name = 'miapp/editarhabitacion.html'
    success_url = reverse_lazy('Listarhabitacion')

class habitacionDelete(DeleteView):
    model = habitacion
    template_name = 'miapp/eliminarhabitacion.html'
    success_url = reverse_lazy('Listarhabitacion')

class clienteCreate(CreateView):
    model = cliente
    fields = ['nombre','apellido','dni','domicilio','genero','telefono','mail']
    template_name = 'miapp/nuevo_cliente.html'
    success_url = reverse_lazy('Listarhabitacion')

class clienteUpdate(UpdateView):
    model = cliente
    template_name = 'miapp/editarcliente.html'
    success_url = reverse_lazy('listar_cliente')

class clienteDelete(DeleteView):
    model = cliente
    template_name = 'miapp/eliminarcliente.html'
    success_url = reverse_lazy('listar_cliente')
